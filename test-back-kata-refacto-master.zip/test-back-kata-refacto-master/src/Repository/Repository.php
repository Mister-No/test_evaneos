<?php

interface Repository
{
    public function getById($id);
}